(function (window) {
    'use strict';
    window.opspark = window.opspark || {};
    window.opspark.collectable = window.opspark.collectable || {};
    let collectable = window.opspark.collectable;
    
    let type = {
        db: {assetKey: 'db', points: 10},
        max: {assetKey: 'max', points: 20},
        steve: {assetKey: 'steve', points: 30},
        grace: {assetKey: 'grace', points: 40},
        kennedi: {assetKey: 'kennedi', points: 50}
    };
    
    
        collectable.create(type.steve, 400, 170, 1, 1);
        collectable.create(type.kennedi, 660, 170, 1, 1);
        collectable.create(type.grace, 100, 170, 1, 1);
        collectable.create(type.db, 200, 190, 1, 1);
        collectable.create(type.max, 150,200, 1, 1);
})(window);